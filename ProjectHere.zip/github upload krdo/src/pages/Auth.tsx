import React from 'react';
import AuthForm from '../components/Auth/AuthForm';

const Auth: React.FC = () => {
  return <AuthForm />;
};

export default Auth;